package org.cybertech.easyExcel;

import org.cybertech.easyExcel.po.ImportVo;
import org.jeecgframework.poi.excel.ExcelImportUtil;
import org.jeecgframework.poi.excel.entity.ImportParams;

import java.io.File;
import java.util.Collections;
import java.util.List;

public class Test {

    public static void main(String[] args) {
//        params.setHeadRows(1); //头行忽略的行数
        // 表格标题占用行数
//        params.setTitleRows(1);
//        // 表头占用行数
//        params.setHeadRows(0)

        File file = new File("F://Upload");
        ImportParams params = new ImportParams();
        // 表格标题占用行数
        params.setTitleRows(1);
        // 表头占用行数
        params.setHeadRows(0);
        // 是否需要保存上传的Excel
        params.setNeedSave(true);


    }


}
