package org.cybertech.easyExcel.example1;

import org.cybertech.easyExcel.example1.entity.Person;
import org.cybertech.easyExcel.example1.util.FileUtil;

import java.util.List;

public class Test {

    public static void main(String[] args) {
        String filePath = "E:\\template-careStrategy.xlsx";
        //解析excel，
        List<Person> personList = FileUtil.importExcel(filePath,1,1,Person.class);
        //也可以使用MultipartFile,使用 FileUtil.importExcel(MultipartFile file, Integer titleRows, Integer headerRows, Class<T> pojoClass)导入
        System.out.println("导入数据一共【"+personList.size()+"】行");
    }
}
