package org.cybertech.easyExcel.po;

import lombok.Data;
import org.jeecgframework.poi.excel.annotation.Excel;

@Data
public class ImportVo {

    @Excel(name = "单元格名称")
    private String cellName;

}
