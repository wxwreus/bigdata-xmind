package org.cybertech.lambda;

import org.cybertech.lambda.entity.KV;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class List2Map {

    public static void main(String[] args) {
        List<KV> kvList =new ArrayList<>();
        for(int i=0; i<10; i++){
            KV kv = new KV();
            kv.setKey("key:"+i);
            kv.setKey("value:"+i);
            kvList.add(kv);
        }
        Map<String, String> kvMap = kvList.stream().collect(Collectors.toMap(KV::getKey, KV::getValue));
        kvMap.forEach((key, value) -> {
            System.out.println("key:"+key+"，value:"+value);
        });

    }
}
