package org.cybertech.lambda.entity;


import lombok.Data;

@Data
public class KV {

    private String key;

    private String value;

}
