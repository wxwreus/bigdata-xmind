package com.util.common.redis.config;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.util.Properties;

public class RedisConfig {

    public static StringRedisTemplate getOpsRedisTemplateObj(){
        YamlPropertiesFactoryBean yamlMapFactoryBean = new YamlPropertiesFactoryBean();
        //可以加载多个yml文件
        yamlMapFactoryBean.setResources(new ClassPathResource("application.yml"));
        Properties properties = yamlMapFactoryBean.getObject();
        //获取yml里的参数
        String host = properties.getProperty("spring.redis.host");
        System.out.println("host:"+host);
        int port = Integer.parseInt(properties.getProperty("spring.redis.port"));
        System.out.println("port:"+port);
        RedisStandaloneConfiguration rsc = new RedisStandaloneConfiguration();
        rsc.setPort(port);
        rsc.setHostName(host);
        //单机模式
        StringRedisTemplate template = new StringRedisTemplate();
        JedisConnectionFactory fac = new JedisConnectionFactory(rsc);
        fac.afterPropertiesSet();
        template.setDefaultSerializer(new StringRedisSerializer());
        template.setConnectionFactory(fac);
        template.afterPropertiesSet();
        return template;
    }
}
