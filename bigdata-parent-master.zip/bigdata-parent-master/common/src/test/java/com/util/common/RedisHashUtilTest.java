package com.util.common;


import com.util.common.redis.RedisHashUtil;
import org.junit.Test;

public class RedisHashUtilTest {

    @Test
    public void test(){
        RedisHashUtil redisHashUtil = new RedisHashUtil();
        redisHashUtil.hPut("province_percent","南极光4", String.valueOf(20));
    }
}
