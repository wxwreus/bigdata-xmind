package org.cybertech.datasourceDelivery.generator;

import org.cybertech.datasourceDelivery.util.ChineseAreaList;
import org.cybertech.entity.KV;
import org.cybertech.entity.ProvinceCity;

import java.util.*;

public class GenerateProvinceCityJson {

    public static ProvinceCity getRandProvinceCity(int randPro){
        Set<String> provinceSet = new HashSet<>();
        //获取省字典
        List<String> provinceCityList = ChineseAreaList.provinceCityList;
        for(String provinceCity : provinceCityList){
            if(provinceCity.contains("省")){
                String key = provinceCity.split("省")[0]+"省";
                provinceSet.add(key);
            }else if(provinceCity.contains("自治区")){
                String key = provinceCity.split("自治区")[0]+"自治区";
                provinceSet.add(key);
            }else if(provinceCity.contains("上海市")){
                provinceSet.add("上海市");
            }else if(provinceCity.contains("北京市")){
                provinceSet.add("北京市");
            }else if(provinceCity.contains("重庆市")){
                provinceSet.add("重庆市");
            }else if(provinceCity.contains("天津市")){
                provinceSet.add("天津市");
            }
        }
        List<KV> kvList = new ArrayList<>();
        Iterator<String> iterator = provinceSet.iterator();
        while (iterator.hasNext()){
            String next = iterator.next();//省、直辖市、自治区
            KV kv = new KV();
            kv.setProvinceKey(next);
            if(next.contains("上海市")){
                kvList.add(kv);
                continue;
            }else if(next.contains("北京市")){
                kvList.add(kv);
                continue;
            }else if(next.contains("重庆市")){
                kvList.add(kv);
                continue;
            }else if(next.contains("天津市")){
                kvList.add(kv);
                continue;
            }else if(next.contains("台湾省")){
                kvList.add(kv);
                continue;
            }
            for (String provinceCity : provinceCityList){
                if(provinceCity.contains(next)){
                    String city = provinceCity.split(next)[1];
                    kv.getCityList().add(city);//城市
                }
            }
            kvList.add(kv);
        }
        KV kv = kvList.get(randPro);
        List<String> cityList = kv.getCityList();
        if(cityList.size() == 0){
            return new ProvinceCity("",kv.getProvinceKey());
        }
        int randCity = new Random().nextInt(cityList.size());
        String provinceKey = kv.getProvinceKey();
        String cityName = cityList.get(randCity);
        return new ProvinceCity(provinceKey,cityName);
    }
    public static void main(String[] args) {

        for(int i=0;i<10;i++){
            ProvinceCity provinceCity = getRandProvinceCity(new Random().nextInt(32));
            System.out.println(provinceCity);
        }
    }
}
