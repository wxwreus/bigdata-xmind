package org.cybertech.datasourceDelivery.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RandType {

    //寄件类型
    public static String[] type = {"文件","衣服","行李","手机","书籍","奶粉","灯具","箱包","茶叶","羊肉"};

    //车辆类型
    public static String[] cllx = {"重型货车","中型货车","轻型货车","微型货车"};

    //当前时间
    public static String currentTime(){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simpleDateFormat.format(new Date());
        return format;
    }

}
