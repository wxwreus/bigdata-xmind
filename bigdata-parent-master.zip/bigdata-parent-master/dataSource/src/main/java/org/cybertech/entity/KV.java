package org.cybertech.entity;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class KV {

    private String provinceKey;

    private List<String> cityList = new ArrayList<>();

}
