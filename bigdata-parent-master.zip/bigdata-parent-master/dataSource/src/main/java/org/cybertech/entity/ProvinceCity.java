package org.cybertech.entity;

import lombok.Data;

@Data
public class ProvinceCity {

    private String provinceName;

    private String cityName;

    public ProvinceCity(){}

    public ProvinceCity(String provinceKey, String cityName) {
        this.provinceName = provinceKey;
        this.cityName = cityName;
    }
}
