package org.cybertech.entity;

import org.cybertech.datasourceDelivery.util.ChineseAreaList;

import java.util.*;

public class ProvinceCityPercent {

    public static Map<String,Integer> provincePercent = null;

    static Map<String,Integer> cityPercent = null;


    static {
        provincePercent = new HashMap<>();
        provincePercent.put("",1);
        Set<String> provinceSet = new LinkedHashSet<>();
        //获取省字典
        List<String> provinceCityList = ChineseAreaList.provinceCityList;
        for(String provinceCity : provinceCityList){
            if(provinceCity.contains("省")){
                String key = provinceCity.split("省")[0]+"省";
                provinceSet.add(key);
            }else if(provinceCity.contains("自治区")){
                String key = provinceCity.split("自治区")[0]+"自治区";
                provinceSet.add(key);
            }else if(provinceCity.contains("上海市")){
                provinceSet.add("上海市");
            }else if(provinceCity.contains("北京市")){
                provinceSet.add("北京市");
            }else if(provinceCity.contains("重庆市")){
                provinceSet.add("重庆市");
            }else if(provinceCity.contains("天津市")){
                provinceSet.add("天津市");
            }
        }
        Iterator<String> iterator = provinceSet.iterator();
        System.out.println(provinceSet.size());
        while (iterator.hasNext()){
            String next = iterator.next();
            switch (next){
                case "黑龙江省":
//                    System.out.println("黑龙江省");
                    provincePercent.put(next,1);
                    break;
                case "青海省":
//                    System.out.println("青海省");
                    provincePercent.put(next,1);
                    break;
                case "陕西省":
//                    System.out.println("陕西省");
                    provincePercent.put(next,1);
                    break;
                case "重庆市":
//                    System.out.println("重庆市");
                    provincePercent.put(next,1);
                    break;
                case "辽宁省":
//                    System.out.println("辽宁省");
                    provincePercent.put(next,1);
                    break;
                case "贵州省":
//                    System.out.println("贵州省");
                    provincePercent.put(next,1);
                    break;
                case "西藏自治区":
//                    System.out.println("西藏自治区");
                    provincePercent.put(next,1);
                case "福建省":
//                    System.out.println("福建省");
                    provincePercent.put(next,1);
                case "甘肃省":
//                    System.out.println("甘肃省");
                    provincePercent.put(next,1);
                case "湖南省":
                    System.out.println("湖南省");
                    provincePercent.put(next,1);
                case "湖北省":
//                    System.out.println("湖北省");
                    provincePercent.put(next,1);
                case "海南省":
//                    System.out.println("海南省");
                    provincePercent.put(next,1);
                case "浙江省":
//                    System.out.println("浙江省");
                    provincePercent.put(next,1);
                case "河南省":
//                    System.out.println("河南省");
                    provincePercent.put(next,1);
                case "河北省":
                    System.out.println("河北省");
                    provincePercent.put(next,1);
                case "江西省":
                    System.out.println("江西省");
                    provincePercent.put(next,1);
                case "江苏省":
                    System.out.println("江苏省");
                    provincePercent.put(next,1);
                case "新疆维吾尔自治区":
                    System.out.println("新疆维吾尔自治区");
                    provincePercent.put(next,1);
                case "广西壮族自治区":
                    System.out.println("广西壮族自治区");
                    provincePercent.put(next,1);
                case "广东省":
                    System.out.println("广东省");
                    provincePercent.put(next,1);
                case "山西省":
                    System.out.println("山西省");
                    provincePercent.put(next,1);
                case "山东省":
                    System.out.println("山东省");
                    provincePercent.put(next,1);
                case "安徽省":
                    System.out.println("安徽省");
                    provincePercent.put(next,1);
                case "宁夏回族自治区":
                    System.out.println("宁夏回族自治区");
                    provincePercent.put(next,1);
                case "天津市":
                    System.out.println("天津市");
                    provincePercent.put(next,1);
                case "四川省":
                    System.out.println("四川省");
                    provincePercent.put(next,1);
                case "吉林省":
                    System.out.println("吉林省");
                    provincePercent.put(next,1);
                case "台湾省":
                    System.out.println("台湾省");
                    provincePercent.put(next,1);
                case "北京市":
                    System.out.println("北京市");
                    provincePercent.put(next,1);
                default:
                    System.out.println(">>>>>>>异常>>>>>>");
            }
            provincePercent.put(next,1);
//            System.out.println(next);
        }

    }

    public static void main(String[] args) {
        new ProvinceCityPercent();
    }

}
