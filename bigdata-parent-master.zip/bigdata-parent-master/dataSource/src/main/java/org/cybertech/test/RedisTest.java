package org.cybertech.test;

import com.util.common.redis.RedisHashUtil;
import org.cybertech.datasourceDelivery.util.ChineseAreaList;
import org.cybertech.entity.KV;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.*;

public class RedisTest {

    @Autowired
    private static StringRedisTemplate redisTemplate;

    public static void main(String[] args) {
        initCityPercent();
    }
    static void initProvincePercent() {
        RedisHashUtil redisHashUtil = new RedisHashUtil();
        Set<String> provinceSet = new HashSet<>();
        //获取省字典
        List<String> provinceCityList = ChineseAreaList.provinceCityList;
        for(String provinceCity : provinceCityList){
            if(provinceCity.contains("省")){
                String key = provinceCity.split("省")[0]+"省";
                provinceSet.add(key);
            }else if(provinceCity.contains("自治区")){
                String key = provinceCity.split("自治区")[0]+"自治区";
                provinceSet.add(key);
            }else if(provinceCity.contains("上海市")){
                provinceSet.add("上海市");
            }else if(provinceCity.contains("北京市")){
                provinceSet.add("北京市");
            }else if(provinceCity.contains("重庆市")){
                provinceSet.add("重庆市");
            }else if(provinceCity.contains("天津市")){
                provinceSet.add("天津市");
            }
        }
        Iterator<String> iterator = provinceSet.iterator();
        while (iterator.hasNext()){
            String next = iterator.next();
            //初始化
            redisHashUtil.hPut("province_percent",next,String.valueOf(20));
            System.out.println(">>>>>>"+next);
        }
    }

    static void initCityPercent() {
        RedisHashUtil redisHashUtil = new RedisHashUtil();
        Map<Object, Object> province_percent = redisHashUtil.hGetAll("province_percent");
        Iterator<Map.Entry<Object, Object>> iterator = province_percent.entrySet().iterator();
        while (iterator.hasNext()){
            String key = (String) iterator.next().getKey();
            System.out.println(key);
            if(key.contains("上海市")){
                continue;
            }else if(key.contains("北京市")){
                continue;
            }else if(key.contains("重庆市")){
                continue;
            }else if(key.contains("天津市")){
                continue;
            }else if(key.contains("台湾省")){
                continue;
            }
            for (String provinceCity : ChineseAreaList.provinceCityList){
                if(provinceCity.contains(key)){
                    String city = provinceCity.split(key)[1];
                    redisHashUtil.hPut(key,city,"15");
                }
            }
        }
    }
}
