package org.cybertech.cdc.mysql;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.ververica.cdc.connectors.mysql.MySQLSource;
import com.alibaba.ververica.cdc.connectors.mysql.table.StartupOptions;
import com.alibaba.ververica.cdc.debezium.DebeziumSourceFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class Mysql2PrintCDC {

    public static void main(String[] args) throws Exception {
        //1.创建执行环境
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        //2.Flink-CDC 将读取 binlog 的位置信息以状态的方式保存在 CK,如果想要做到断点续传,需要从 Checkpoint 或者 Savepoint 启动程序
        //2.1 开启 Checkpoint,每隔 5 秒钟做一次 CK
        env.enableCheckpointing(5000L);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        //3 设置任务关闭的时候保留最后一次CK数据
        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
        //4.指定从CK重启策略
        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 2000L));
        //5.设置状态后端
        env.setStateBackend(new FsStateBackend("hdfs://bigdata-pro01:9000/flinkCDC"));
        //6.设置访问的HDFS的用户名
        System.setProperty("HADOOP_USER_NAME","kfk");

        /**
         * 使用MySQLSource创建数据源
         * 同时指定StringDebeziumDeserializationSchema，将CDC转换为String类型输出
         */
        DebeziumSourceFunction<JSONObject> mysqlSource = MySQLSource
                .<JSONObject>builder()
                .hostname("bigdata-pro01.kfk.com")
                .port(3306)
                .databaseList("flink").tableList("flink.runoob_tbl")
                .startupOptions(StartupOptions.initial())
                .username("root")
                .password("Root@123").serverTimeZone("Asia/Shanghai")
                .deserializer(new CdcDwdDeserializationSchema()).build();
        //单并行度打印，避免输出乱序
        env.addSource(mysqlSource).setParallelism(1).print();
        env.execute("mysql-cdc");
    }
}
