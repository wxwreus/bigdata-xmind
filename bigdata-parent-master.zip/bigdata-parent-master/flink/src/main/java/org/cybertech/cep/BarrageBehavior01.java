package org.cybertech.cep;

import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.cep.CEP;
import org.apache.flink.cep.PatternSelectFunction;
import org.apache.flink.cep.PatternStream;
import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.cep.pattern.conditions.SimpleCondition;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * 用户如果在 10s 内，同时输入 TMD 超过 5 次，就认为用户为恶意攻击，识别出该用户
 */
public class BarrageBehavior01 {
    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.setParallelism(1);

        List<Tuple3<String, String, Long>> tuple3s = Arrays.asList(new Tuple3<String, String, Long>("1", "TMD", 1618498576L),
                new Tuple3<String, String, Long>("1", "TMD", 1618498577L),
                new Tuple3<String, String, Long>("1", "TMD", 1618498579L),
                new Tuple3<String, String, Long>("1", "TMD", 1618498582L),
                new Tuple3<String, String, Long>("2", "TMD", 1618498583L),
                new Tuple3<String, String, Long>("1", "TMD", 1618498585L));
        DataStreamSource<Tuple3<String, String, Long>> dataStreamSource = env.fromCollection(tuple3s);
        //定义EventTime
        KeyedStream<Tuple3<String, String, Long>, String> keyedStream =
                dataStreamSource.assignTimestampsAndWatermarks(WatermarkStrategy.<Tuple3<String, String, Long>>forMonotonousTimestamps()
                        .withTimestampAssigner(new SerializableTimestampAssigner<Tuple3<String, String, Long>>() {
                            @Override
                            public long extractTimestamp(Tuple3<String, String, Long> tuple3, long l) {
                                return tuple3.f2;
                            }
                        })
        ).keyBy(r -> r.f0);
        Pattern<Tuple3<String, String, Long>, Tuple3<String, String, Long>> begin = Pattern.<Tuple3<String, String, Long>>begin("begin").where(new SimpleCondition<Tuple3<String, String, Long>>() {
            @Override
            public boolean filter(Tuple3<String, String, Long> tuple3) throws Exception {
                return tuple3.f1.equals("TMD");
            }
        }).times(3).within(Time.seconds(10));
        PatternStream<Tuple3<String, String, Long>> pattern = CEP.pattern(keyedStream, begin);
        pattern.select(new PatternSelectFunction<Tuple3<String, String, Long>, String>() {
            @Override
            public String select(Map<String, List<Tuple3<String, String, Long>>> map) throws Exception {
                Tuple3<String, String, Long> result = map.get("begin").get(0);
                return "用户: "+result.f0+",内容:"+result.f1;
            }
        }).print();
        env.execute("barrageBehavior01");
    }
}
