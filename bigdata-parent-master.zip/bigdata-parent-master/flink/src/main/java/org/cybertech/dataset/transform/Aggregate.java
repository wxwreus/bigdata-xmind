package org.cybertech.dataset.transform;

import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.aggregation.Aggregations;
import org.apache.flink.api.java.operators.AggregateOperator;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple3;

import java.util.ArrayList;
import java.util.List;

/**
 * 经过Aggregate.MAX,
 * Aggregations.MIN,
 * Aggregations.SUM处理的结果key和value是不对应的
 *
 * 当遇到最小值后，将第后一次出现的最小值所在的整个元素返回
 */
public class Aggregate {

    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        List<Tuple3> tuple3List = new ArrayList<Tuple3>();
        tuple3List.add(new Tuple3(3,"yuwen",89.99));
        tuple3List.add(new Tuple3(1,"yuwen",89.0));
        tuple3List.add(new Tuple3(2,"shuxue",92.2));

        DataSource<Tuple3> ds = env.fromCollection(tuple3List);
        AggregateOperator<Tuple3> aggregate = ds.groupBy(1).aggregate(Aggregations.MAX, 2);
        aggregate.print();
    }
}
