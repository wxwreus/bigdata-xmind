package org.cybertech.dataset.transform;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple2;

import java.util.Arrays;
import java.util.List;

/**
 * minBy在计算的过程中，当遇到最小值后，将第一次出现的最小值所在的整个元素返回
 */
public class MinByAndMaxBy {

    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        List<String> strings = Arrays.asList("张三,1", "李四,2", "王五,3", "张三,4");
        DataSource<String> dataSource = env.fromCollection(strings);
        DataSet<Tuple2<String, Integer>> map =
                dataSource.map(new MapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(String line) throws Exception {
                String name = line.split(",")[0];
                Integer id = Integer.parseInt(line.split(",")[1]);
                return new Tuple2(name, id);
            }
        });
        DataSet<Tuple2<String, Integer>> maxBy = map.groupBy(0).maxBy(1);
        maxBy.print();
        env.execute("minAndMax");
    }
}
