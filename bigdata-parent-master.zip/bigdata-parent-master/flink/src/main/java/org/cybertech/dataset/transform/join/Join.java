package org.cybertech.dataset.transform.join;

import org.apache.flink.api.common.functions.JoinFunction;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.operators.JoinOperator;
import org.apache.flink.api.java.tuple.Tuple2;
import java.util.ArrayList;
import java.util.List;

public class Join {

    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        List<Tuple2<Long, String>> tuple1List = new ArrayList<Tuple2<Long, String>>();
        tuple1List.add(new Tuple2(3L,"yuwen"));
        tuple1List.add(new Tuple2(1L,"yuwen"));
        tuple1List.add(new Tuple2(2L,"shuxue"));
        DataSource<Tuple2<Long, String>> ds1 = env.fromCollection(tuple1List);

        List<Tuple2<Long, Double>> tuple2List = new ArrayList<Tuple2<Long, Double>>();
        tuple2List.add(new Tuple2<Long, Double>(3L,89.99));
        tuple2List.add(new Tuple2<Long, Double>(1L,89.0));
        tuple2List.add(new Tuple2<Long, Double>(2L,92.2));
        DataSource<Tuple2<Long, Double>> ds2 = env.fromCollection(tuple2List);

        JoinOperator.EquiJoin<Tuple2<Long, String>, Tuple2<Long, Double>, Tuple2<Long, String>> with
                = ds1.join(ds2).where(0).equalTo(0)
                .with(new JoinFunction<Tuple2<Long, String>, Tuple2<Long, Double>, Tuple2<Long, String>>() {
            @Override
            public Tuple2<Long, String> join(Tuple2<Long, String> x, Tuple2<Long, Double> y) throws Exception {
                return new Tuple2<>(x.f0, x.f1 + "," + y.f1);
            }
        });
        with.print();
    }
}
