package org.cybertech.datastream.broadcast;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ReadOnlyBroadcastState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;

/**
 * 在Flink使用场景中，外部的配置文件或计算规则及维表等进行预加载，并定期更新，流式计算中广播小变量等场景。
 *
 * 广播状态（State）必须是 MapState 类型，
 *
 * 1.预加载
 * 在算子的open()方法中读取MySQL或其他存储介质，获取全量维表信息比如在算子RichMapFunction的open()方法中获取全部数据，然后在算子中进行使用，这种方法的缺点是如果外部数据更新了Flink是没法知道的，这就需要在开启一个定时任务定时从MySQL中获取最新的数据。
 *
 * 2.外部查询
 * 数据不需要存储，仅需要用到外部数据的时候去进行查询，可以保证查询到的数据是最新的，但是对于吞吐量较高的场景，可能与外部（比如MySQL）交互就变成了 Flink任务的瓶颈，虽然可以设置为异步I/O的形式进行交互优化，但优化程度一般有限。
 *
 * 3.本地缓存
 * 需要设置过期时间或者定时更新数据，当数据到达过期时间后从新从外部获取，或者定时从外部捞取数据进行更新，不能在外部数据发生变动时，及时更新到Flink程序中。
 */
public class FlinkConnectBroadcast {
    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> dataStreamSource = env.readTextFile("E:\\data.txt");
        SingleOutputStreamOperator<Tuple2<String, Long>> mapStream = dataStreamSource.map(new MapFunction<String, Tuple2<String, Long>>() {
            @Override
            public Tuple2<String, Long> map(String s) throws Exception {
                return null;
            }
        });
        DataStream<Long> ruleStream = env.fromElements(3L);
        //一个 map descriptor，它描述了用于存储规则名称与规则本身的 map 存储结构
        MapStateDescriptor<String,Long> ruleStateDescriptor = new MapStateDescriptor<>(
                "RulesBroadcastState",
                BasicTypeInfo.STRING_TYPE_INFO,
                TypeInformation.of(new TypeHint<Long>() {}));

        // 广播流，广播规则并且创建 broadcast state
        BroadcastStream<Long> ruleBroadcastStream = ruleStream.broadcast(ruleStateDescriptor);

        BroadcastConnectedStream<Tuple2<String, Long>, Long> connectedStream = mapStream.connect(ruleBroadcastStream);

        SingleOutputStreamOperator<Object> process = connectedStream.process(new KeyedBroadcastProcessFunction<String, Tuple2<String, Long>, Long, Object>() {
            /**
             * 两个方法均有如下方法：
             * 得到广播流的存储状态：ctx.getBroadcastState(MapStateDescriptor<K, V> stateDescriptor)
             * 查询元素的时间戳：ctx.timestamp()
             * 查询目前的Watermark：ctx.currentWatermark()
             * 目前的处理时间(processing time)：ctx.currentProcessingTime()
             * 产生旁路输出：ctx.output(OutputTag<X> outputTag, X value)
             */
            MapStateDescriptor<String, Long> ruleStateDescriptor = new MapStateDescriptor<>(
                    "RulesBroadcastState",
                    BasicTypeInfo.STRING_TYPE_INFO,
                    TypeInformation.of(new TypeHint<Long>() {
                    }));

            /**
             * 负责处理广播流中的元素
             * @param tuple2
             * @param readOnlyContext
             * @param collector
             * @throws Exception
             */
            @Override
            public void processElement(Tuple2<String, Long> tuple2,
                                       ReadOnlyContext readOnlyContext,
                                       Collector<Object> collector) throws Exception {
                ReadOnlyBroadcastState<String, Long> broadcastState = readOnlyContext.getBroadcastState(ruleStateDescriptor);
                if (broadcastState.contains("rule")) {
                    if (tuple2.f1 > broadcastState.get("rule")) {
                        collector.collect(tuple2.f0 + " : " + tuple2.f1);
                    }
                }
            }

            /**
             * 负责处理非广播流中的元素
             * @param aLong
             * @param context
             * @param collector
             * @throws Exception
             */
            @Override
            public void processBroadcastElement(Long aLong,
                                                Context context,
                                                Collector<Object> collector) throws Exception {
                context.getBroadcastState(ruleStateDescriptor).put("rule", aLong);
            }
        });
        process.print();
        env.execute("broadcastState");
    }
}
