package org.cybertech.datastream.checkpoint;

import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import javax.annotation.Nullable;
import java.util.Iterator;

public class FlinkEventTimeAPIChkMain {

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStateBackend(new FsStateBackend("hdfs://bigdata-pro01:9000/flink-checkpoint/checkpoint/"));
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        env.getCheckpointConfig().setCheckpointInterval(6000);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        //保留策略:默认情况下，检查点不会被保留，仅用于故障中恢复作业，可以启用外部持久化检查点，同时指定保留策略
        //ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION:在作业取消时保留检查点，注意在这种情况下，您必须在取消后手动清理检查点状态
        //ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION:当作业被 cancel 时，删除检查点，检查点状态仅在作业失败时可用
        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION);
        DataStreamSource<Tuple4<Long, String, String, Integer>> dataStreamSource =
                env.addSource(new SourceFunction<Tuple4<Long, String, String, Integer>>() {
            private boolean isRunning = true;
            private Long count = 0L;
            private String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWZYX0987654321";
            @Override
            public void run(SourceContext<Tuple4<Long, String, String, Integer>> sourceContext) throws Exception {
                while (isRunning) {
                    for (long i = 0; i < 10000; i++) {
                        sourceContext.collect(new Tuple4<Long, String, String, Integer>(i, "hello-" + count, alphabet, 1));
                        count += 1L;
                    }
                    Thread.sleep(1000);
                }
            }
            @Override
            public void cancel() {
                isRunning = false;
            }
        });
        //方法已过期，代替方法
        dataStreamSource.assignTimestampsAndWatermarks(new AssignerWithPeriodicWatermarks<Tuple4<Long, String, String, Integer>>() {

            // 设置 watermark
            @Nullable
            @Override
            public Watermark getCurrentWatermark() {
                return new Watermark(System.currentTimeMillis());
            }
            // 给每个元组打上时间戳
            @Override
            public long extractTimestamp(Tuple4<Long, String, String, Integer> longStringStringIntegerTuple4, long l) {
                return System.currentTimeMillis();
            }
        }).keyBy(0).window(SlidingEventTimeWindows.of(Time.seconds(4),Time.seconds(1)))
        .apply(new WindowFunction<Tuple4<Long, String, String, Integer>, Long, Tuple, TimeWindow>() {
            private Long total = 0L;
            @Override
            public void apply(Tuple tuple, TimeWindow timeWindow, Iterable<Tuple4<Long, String, String, Integer>> iterable,
                              Collector<Long> collector) throws Exception {
                Long count = 0L;
                Iterator<Tuple4<Long, String, String, Integer>> iterator = iterable.iterator();
                while (iterator.hasNext()){
                    count += 1L;
                }
                total += count;
                collector.collect(count);
            }
        }).print();
        env.execute("flinkEventTimeAPIChkMain");
    }
}
