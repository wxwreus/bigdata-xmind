package org.cybertech.datastream.function;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.com.google.common.base.Supplier;
import org.apache.flink.streaming.api.datastream.AsyncDataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.async.ResultFuture;
import org.apache.flink.streaming.api.functions.async.RichAsyncFunction;
import org.cybertech.datastream.source.MySelfSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * 1.异步获取数据库关联信息
 * 2.代码基于无序api开发，
 * 3.数据库mysql在数据量大的情况可以改造成redis
 */
public class AsynchronousMysqlFunction {

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> dataStreamSource = env.addSource(new MySelfSource());
        SingleOutputStreamOperator<Tuple2<String, String>> async = AsyncDataStream.unorderedWait(
                dataStreamSource,
                new AsyncDatabaseRequest(),
                10000,
                TimeUnit.MICROSECONDS,
                100);
        async.print();
        env.execute("asyncForMysql");
    }

    static class AsyncDatabaseRequest extends RichAsyncFunction<String, Tuple2<String, String>>{

        private DruidDataSource dataSource;

        @Override
        public void open(Configuration parameters) throws Exception {
            super.open(parameters);
            dataSource = new DruidDataSource();
            dataSource.setDriverClassName("com.mysql.jdbc.Driver");
            dataSource.setUrl("jdbc:mysql://bigdata-pro01/db_novel?createDatabaseIfNotExist=true");
            dataSource.setUsername("root");
            dataSource.setPassword("root123");
        }

        @Override
        public void asyncInvoke(String key, ResultFuture<Tuple2<String, String>> resultFuture) throws Exception {
            String chapter_name = queryFormMysql(key);
            CompletableFuture.supplyAsync(new Supplier<Tuple2<String,String>>() {
                @Override
                public Tuple2<String,String> get() {
                    return new Tuple2<>(key , chapter_name);
                }
            }).thenAccept(dbResult -> {
                resultFuture.complete(Collections.singleton(dbResult));
            });
        }

        private String queryFormMysql(String id) throws SQLException {
            String sql = "select chapter_name from novel_detail where id =? ";
            Connection connection = null ;
            PreparedStatement stmt = null ;
            ResultSet rs = null ;
            String result_name = null ;
            try{
                connection = dataSource.getConnection();
                stmt = connection.prepareStatement(sql);
                stmt.setString(1,id);
                rs = stmt.executeQuery() ;
                if (rs.next()){
                    result_name = rs.getString("chapter_name") ;
                }
            }catch (SQLException e){
                e.printStackTrace();
            }finally {
                if(rs != null){
                    rs.close();
                }
                if (stmt != null){
                    stmt.close();
                }
                if (connection != null){
                    connection.close();
                }
            }
            return result_name  ;
        }
        @Override
        public void close() throws Exception {
            super.close();
            dataSource.close();
        }
    }
}
