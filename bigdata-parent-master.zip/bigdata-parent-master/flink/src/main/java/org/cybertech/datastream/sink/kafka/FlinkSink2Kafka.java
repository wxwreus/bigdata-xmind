package org.cybertech.datastream.sink.kafka;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;

import java.util.Properties;

public class FlinkSink2Kafka {

    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(3);
        DataStreamSource<String> dataStreamSource = env.addSource(new SourceFunction<String>() {
            @Override
            public void run(SourceContext<String> sourceContext) throws Exception {

                while (true) {
//                    Delivery delivery = AutoData.generateData();
//                    String line = delivery.toString();
//                    System.out.println(line);
//                    sourceContext.collect(line);
                    String[] datas = {
                            "a,1575159390000",
                            "a,1575159402000",
                            "b,1575159427000",
                            "c,1575159382000",
                            "b,1575159407000",
                            "a,1575159302000"
                    };
                    for (int k = 0; k < datas.length; k++) {
//                        Thread.sleep(100);
                        sourceContext.collect(datas[k]);
                    }
                    Thread.sleep(50);
                }
            }
            @Override
            public void cancel() {

            }
        });
        Properties properties = new Properties();
        properties.put("bootstrap.servers", "bigdata-centos7-one:9092");
        properties.put("acks", "all");//相当于acks=-1 ,只有一个副本时，没有意义，默认是acks=1
        properties.put("retries", 0);
        properties.put("batch.size", 16384);//批次的大小，16K
        properties.put("linger.ms", 10);//等待时间，10ms
        properties.put("buffer.memory", 33554432);//缓冲区大小，32M
        properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        properties.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");

        dataStreamSource.addSink(new FlinkKafkaProducer<String>("protest",
                new SimpleStringSchema(),
                properties)).name("flink-connectors-kafka").setParallelism(1);
        env.execute("flinkSource-2-kafka");
    }
}
