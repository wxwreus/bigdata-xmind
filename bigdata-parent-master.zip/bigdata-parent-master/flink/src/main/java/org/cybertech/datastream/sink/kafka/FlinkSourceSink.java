package org.cybertech.datastream.sink.kafka;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.cybertech.entity.Delivery;
import org.cybertech.util.AutoData;


public class FlinkSourceSink {

    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(3);
        DataStreamSource<String> dataStreamSource = env.addSource(new SourceFunction<String>() {
            @Override
            public void run(SourceContext<String> sourceContext) throws Exception {

                while (true) {
                    Delivery delivery = AutoData.generateData();
                    String line = delivery.toString();
                    System.out.println(line);
                    sourceContext.collect(line);
                    Thread.sleep(500);
                }
            }
            @Override
            public void cancel() {

            }
        });
        dataStreamSource.print();
        env.execute("flinkRedisSource-2-kafka");
    }
}
