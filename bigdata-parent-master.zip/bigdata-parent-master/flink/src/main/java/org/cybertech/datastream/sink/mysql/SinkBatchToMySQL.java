package org.cybertech.datastream.sink.mysql;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

/**
 * Desc: 数据批量 sink 数据到 mysql
 */
public class SinkBatchToMySQL extends RichSinkFunction<List<Tuple2<String,Long>>> {

    PreparedStatement ps;
    BasicDataSource dataSource;
    private Connection connection;

    /**
     * open() 方法中建立连接，这样不用每次 invoke 的时候都要建立连接和释放连接
     * @param parameters
     * @throws Exception
     */
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        dataSource = new BasicDataSource();
        connection = getConnection(dataSource);
        String sql = "insert into test(`key`, `value`) values(?, ?);";
        ps = connection.prepareStatement(sql);
    }

    @Override
    public void close() throws Exception {
        super.close();
        //关闭连接和释放资源
        if (connection != null) {
            connection.close();
        }
        if (ps != null) {
            ps.close();
        }
    }
    /**
     * 每条数据的插入都要调用一次 invoke() 方法
     * @param value
     * @param context
     * @throws Exception
     */
    @Override
    public void invoke(List<Tuple2<String,Long>> value, Context context) throws Exception {
        System.out.println(">>>>>>>开始插入数据库size>>>>>>"+value.size());
        //遍历数据集合
        for (Tuple2<String,Long> tuple2 : value) {
            ps.setString(1, tuple2.f0);
            ps.setLong(2, tuple2.f1);
            ps.addBatch();
        }
        int[] count = ps.executeBatch();//批量后执行
        System.out.println("成功了插入了" + count.length + "行数据");
    }

    private static Connection getConnection(BasicDataSource dataSource) {
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        //注意，替换成自己本地的 mysql 数据库地址和用户名、密码
        dataSource.setUrl("jdbc:mysql://127.0.0.1:3306/flink?serverTimezone=GMT");
        dataSource.setUsername("root");
        dataSource.setPassword("root123");
        //设置连接池的一些参数
        dataSource.setInitialSize(5);
        dataSource.setMaxTotal(10);
        dataSource.setMinIdle(2);
        Connection con = null;
        try {
            con = dataSource.getConnection();
            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>创建连接池：" + con);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("-----------mysql get connection has exception , msg = " + e.getMessage());
        }
        return con;
    }
}
