package org.cybertech.datastream.sink.mysql;

import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Iterator;

public class SinkToMySQL {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        KeyedStream<Tuple2<String, Long>, String> keyByDS = env.addSource(new SourceFunction<String>() {
            @Override
            public void run(SourceContext<String> sourceContext) throws Exception {
                String[] datas = {
                        "a",
                        "a",
                        "b",
                        "c",
                        "b",
                        "a"
                };
                while (true) {
                    for (int k = 0; k < datas.length; k++) {
                        Thread.sleep(100);
                        System.out.println("dataSource>>"+datas[k]+","+System.currentTimeMillis());
                        sourceContext.collect(datas[k]+","+System.currentTimeMillis());
                    }
                    Thread.sleep(5000);
                }
            }
            @Override
            public void cancel() {

            }
        }).map(new MapFunction<String, Tuple2<String, Long>>() {
            @Override
            public Tuple2<String, Long> map(String line) throws Exception {
                String[] split = line.split(",");
                return new Tuple2<String, Long>(split[0],Long.parseLong(split[1]));
            }
        }).assignTimestampsAndWatermarks(WatermarkStrategy.<Tuple2<String, Long>>forMonotonousTimestamps()
                .withTimestampAssigner(new SerializableTimestampAssigner<Tuple2<String, Long>>() {
                    @Override
                    public long extractTimestamp(Tuple2<String, Long> tuple2, long l) {
                        System.out.println(">>>>>>time:"+tuple2.f0+","+tuple2.f1);
                        return tuple2.f1;
                    }
                })).keyBy(ele -> ele.f0);
        SingleOutputStreamOperator<Tuple2<String, Long>> apply = keyByDS.window(TumblingEventTimeWindows.of(Time.seconds(20L)))
            .apply(new WindowFunction<Tuple2<String, Long>, Tuple2<String, Long>, String, TimeWindow>() {
                @Override
                public void apply(String key,
                                  TimeWindow timeWindow,
                                  Iterable<Tuple2<String, Long>> iterable,
                                  Collector<Tuple2<String, Long>> collector) throws Exception {
                    Iterator<Tuple2<String, Long>> iterator = iterable.iterator();
                    Long cnt = 0L;
                    while (iterator.hasNext()){
                        Tuple2<String, Long> next = iterator.next();
                        System.out.println(next.f0);
                        cnt ++;
                    }
                    Tuple2<String, Long> tuple2 = new Tuple2<>(key, cnt);
                    collector.collect(tuple2);
                }
            });
        apply.addSink(new MyJDBCSink());
        env.execute("sinkToMySQL");
    }

    public static class MyJDBCSink extends RichSinkFunction<Tuple2<String, Long>> {
        private Connection conn;
        private PreparedStatement insertStmt;
        private PreparedStatement updateStmt;

        @Override
        public void open(Configuration parameters) throws Exception {
            super.open(parameters);
            conn = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1:3306/flink?serverTimezone=GMT",
                    "root",
                    "root123"
            );
            insertStmt = conn.prepareStatement("INSERT INTO test (`key`, `value`) VALUES (?, ?)");
            updateStmt = conn.prepareStatement("UPDATE test SET `value` = `value`+? WHERE `key` = ?");
        }

        @Override
        public void invoke(Tuple2<String, Long> value, Context context) throws Exception {
            updateStmt.setLong(1, value.f1);
            updateStmt.setString(2, value.f0);
            updateStmt.execute();
            if (updateStmt.getUpdateCount() == 0) {
                insertStmt.setString(1, value.f0);
                insertStmt.setLong(2, value.f1);
                insertStmt.execute();
            }
        }
        @Override
        public void close() throws Exception {
            super.close();
            insertStmt.close();
            updateStmt.close();
            conn.close();
        }
    }
}
