package org.cybertech.datastream.source;

import org.apache.flink.elasticsearch6.shaded.org.elasticsearch.common.collect.Tuple;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

public class OutSourceFunction implements SourceFunction<Tuple<Integer, Integer>> {

    private int count = 0;

    @Override
    public void run(SourceContext<Tuple<Integer, Integer>> sourceContext) throws Exception {
        while (count<100){
            int first = (int)(Math.random() * 10) ;
            sourceContext.collect(new Tuple<Integer, Integer>(first,first));
            count++;
            Thread.sleep(100L);
        }
    }
    @Override
    public void cancel() {

    }
}
