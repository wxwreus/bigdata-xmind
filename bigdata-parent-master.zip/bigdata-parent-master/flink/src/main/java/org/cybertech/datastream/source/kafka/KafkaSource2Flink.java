package org.cybertech.datastream.source.kafka;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class KafkaSource2Flink {

    public static void main(String[] args) throws Exception {

        Properties props = new Properties();
        props.put("bootstrap.servers", "bigdata-centos7-one:9092");
        props.put("zookeeper.connect", "bigdata-centos7-one:2181");
        props.put("group.id", "delivery-group");    //消息组id

        props.put("fetch.min.bytes", "1024");      //该参数指定了每次拉取消息的最小字节数
        props.put("fetch.max.wait.ms", "500");     //该参数指定了 Consumer 等待拉取消息的最长时间
        props.put("max.poll.records", "500");      //该参数指定了每次拉取的最大消息数

        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("auto.offset.reset", "latest");

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> kafkaMessage = env.addSource(new FlinkKafkaConsumer<String>(
                "protest",   //这个 kafka topic 需要和上面的工具类的 topic 一致
                new SimpleStringSchema(),
                props)).setParallelism(1);

//        kafkaMessage.keyBy("").window(new TumblingEventTimeWindows()).
        kafkaMessage.print();
        env.execute("flink-consumer");
    }
}
