package org.cybertech.datastream.state.keyedState;

import com.google.common.collect.Lists;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * 分组求和
 */
public class CountWithKeyedMapState {

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        List<Tuple2<String, Long>> tuple2s = Arrays.asList(
                new Tuple2<String, Long>("java", 4L),
                new Tuple2<String, Long>("python", 3L),
                new Tuple2<String, Long>("java", 1L),
                new Tuple2<String, Long>("scala", 2L),
                new Tuple2<String, Long>("python", 2L),
                new Tuple2<String, Long>("java", 2L),
                new Tuple2<String, Long>("scala", 2L)
        );
        DataStreamSource<Tuple2<String, Long>> tuple2DataStreamSource = env.fromCollection(tuple2s);
        tuple2DataStreamSource.keyBy(new KeySelector<Tuple2<String, Long>, String>() {
            @Override
            public String getKey(Tuple2<String, Long> longLongTuple2) throws Exception {
                return longLongTuple2.f0;
            }
        }).flatMap(new RichFlatMapFunction<Tuple2<String, Long>, Tuple2<String, Double>>() {

            private MapState<String, Long> mapState;

            @Override
            public void open(Configuration parameters) throws Exception {
                MapStateDescriptor descriptor = new MapStateDescriptor("MapDescriptor",String.class,String.class);
                mapState = getRuntimeContext().getMapState(descriptor);
            }

            @Override
            public void flatMap(Tuple2<String, Long> input, Collector<Tuple2<String, Double>> collector) throws Exception {
                //获取状态
                mapState.put(UUID.randomUUID().toString(),input.f1);
                List<Long> allEles = Lists.newArrayList(mapState.values());
                if(allEles.size() >=3){
                    long count = 0;
                    long sum = 0;
                    for (Long ele:allEles) {
                        count ++;
                        sum += ele;
                    }
                    double avg = (double) sum/count;
                    collector.collect(Tuple2.of(input.f0,avg));
                    mapState.clear();
                }
            }
        }).print();
        env.execute("CountWithKeyedState");
    }
}
