package org.cybertech.datastream.state.keyedState;

import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

import java.util.Arrays;
import java.util.List;

/**
 * 分组求和
 */
public class CountWithKeyedValueState {

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        List<Tuple2<Long, Long>> tuple2s = Arrays.asList(
                new Tuple2<Long, Long>(1L, 4L),
                new Tuple2<Long, Long>(2L, 3L),
                new Tuple2<Long, Long>(3L, 1L),
                new Tuple2<Long, Long>(1L, 2L),
                new Tuple2<Long, Long>(3L, 2L),
                new Tuple2<Long, Long>(1L, 2L),
                new Tuple2<Long, Long>(2L, 2L),
                new Tuple2<Long, Long>(2L, 9L)
        );
        DataStreamSource<Tuple2<Long, Long>> tuple2DataStreamSource = env.fromCollection(tuple2s);
        tuple2DataStreamSource.keyBy(new KeySelector<Tuple2<Long, Long>, Long>() {
            @Override
            public Long getKey(Tuple2<Long, Long> longLongTuple2) throws Exception {
                return longLongTuple2.f0;
            }
        }).flatMap(new RichFlatMapFunction<Tuple2<Long, Long>, Tuple2<Long, Long>>() {
            /**
             * ValueState 状态句柄. 第一个值为 count，第二个值为 sum。
             */
            private ValueState<Tuple2<Long, Long>> valueState;
            @Override
            public void open(Configuration parameters) throws Exception {
                ValueStateDescriptor<Tuple2<Long, Long>> descriptor =
                        new ValueStateDescriptor<Tuple2<Long, Long>>("keycount", TypeInformation.of(new TypeHint<Tuple2<Long, Long>>() {}));
                valueState = getRuntimeContext().getState(descriptor);
            }

            @Override
            public void flatMap(Tuple2<Long, Long> tuple2, Collector<Tuple2<Long, Long>> collector) throws Exception {
                Tuple2<Long, Long> currentValue = valueState.value();
                if(currentValue == null){
                    currentValue = new Tuple2<Long, Long>(0L, 0L);
                }
                currentValue.f0 ++;
                currentValue.f1 = currentValue.f1 + tuple2.f1;
                valueState.update(currentValue);
                collector.collect(valueState.value());
            }
        }).setParallelism(1).print();
        env.execute("CountWithKeyedState");
    }
}
