package org.cybertech.datastream.state.operate;

public class ListOperate {

    public static void main(String[] args) {

    }
}
