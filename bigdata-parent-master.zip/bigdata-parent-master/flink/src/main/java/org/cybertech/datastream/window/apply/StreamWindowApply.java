package org.cybertech.datastream.window.apply;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.RichWindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.util.Iterator;

/**
 * 单词统计
 */
public class StreamWindowApply {

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> dataStreamSource = env.socketTextStream("bigdata-pro01", 9999);

        SingleOutputStreamOperator<Tuple2<String, Integer>> flatMap = dataStreamSource.flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public void flatMap(String line, Collector<Tuple2<String, Integer>> collector) throws Exception {
                String[] words = line.split(",");
                for (int i = 0; i < words.length; i++) {
                    collector.collect(new Tuple2<String, Integer>(words[i], 1));
                }
            }
        });

        SingleOutputStreamOperator<Tuple2<String, Integer>> apply =
                flatMap.keyBy(new KeySelector<Tuple2<String, Integer>, String>() {
            @Override
            public String getKey(Tuple2<String, Integer> tuple2) throws Exception {
                return tuple2.f0;
            }
        }).timeWindow(Time.seconds(10))
        .apply(new RichWindowFunction<Tuple2<String, Integer>, Tuple2<String, Integer>, String, TimeWindow>() {
            @Override
            public void apply(String word, TimeWindow timeWindow,
                              Iterable<Tuple2<String, Integer>> iterable,
                              Collector<Tuple2<String, Integer>> collector) throws Exception {
                Iterator<Tuple2<String, Integer>> iterator = iterable.iterator();
                int sum = 0;
                while (iterator.hasNext()){
                    Tuple2<String, Integer> next = iterator.next();
                    sum = sum + next.f1;
                }
                collector.collect(new Tuple2<>(word, sum));
            }
        });
        apply.print();
        env.execute("streamWindowApply");
    }
}
