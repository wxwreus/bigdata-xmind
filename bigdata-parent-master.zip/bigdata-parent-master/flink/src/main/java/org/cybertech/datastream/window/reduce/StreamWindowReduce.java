package org.cybertech.datastream.window.reduce;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

public class StreamWindowReduce {

    public static void main(String[] args) throws Exception {

        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        DataStreamSource<String> dataStreamSource = env.socketTextStream("bigdata-centos7-one", 9999);
        SingleOutputStreamOperator<Tuple2<String, Integer>> map =
            dataStreamSource.flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
                @Override
                public void flatMap(String line, Collector<Tuple2<String, Integer>> collector) throws Exception {
                    String[] words = line.split(",");
                    for(int i=0;i<words.length;i++){
                        collector.collect(new Tuple2<String, Integer>(words[i], 1));
                    }
                }
            });
        WindowedStream<Tuple2<String, Integer>, String, TimeWindow> timeWindows =
                map.keyBy(new KeySelector<Tuple2<String, Integer>, String>() {
            @Override
            public String getKey(Tuple2<String, Integer> tuple2) throws Exception {
                return tuple2.f0;
            }
        }).timeWindow(Time.seconds(10));
        SingleOutputStreamOperator<Tuple2<String, Integer>> reduce =
                timeWindows.reduce(new ReduceFunction<Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> reduce(Tuple2<String, Integer> x, Tuple2<String, Integer> y) throws Exception {
                return new Tuple2<String, Integer>(x.f0, x.f1 + y.f1);
            }
        });
        reduce.print();
        env.execute("streamWindowReduce");
    }
}
