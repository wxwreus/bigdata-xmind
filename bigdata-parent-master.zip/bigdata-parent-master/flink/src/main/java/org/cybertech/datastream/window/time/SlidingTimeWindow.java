package org.cybertech.datastream.window.time;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;

public class SlidingTimeWindow {

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> dataStreamSource = env.socketTextStream("bigdata-pro01", 9999);

        SingleOutputStreamOperator<Tuple2<Integer, Integer>> map = dataStreamSource.map(new MapFunction<String, Tuple2<Integer, Integer>>() {
            @Override
            public Tuple2<Integer, Integer> map(String line) throws Exception {

                String[] words = line.split(",");
                return new Tuple2<Integer, Integer>(Integer.parseInt(words[0]), Integer.parseInt(words[1]));
            }
        });

        SingleOutputStreamOperator<Tuple2<Integer, Integer>> sum = map.keyBy(new KeySelector<Tuple2<Integer, Integer>, Integer>() {
            @Override
            public Integer getKey(Tuple2<Integer, Integer> tuple2) throws Exception {
                return tuple2.f0;
            }
        }).timeWindow(Time.seconds(10), Time.seconds(5)).sum(1);
        sum.print();
        //触发流计算
        env.execute("slidingTimeWindow");
    }
}
