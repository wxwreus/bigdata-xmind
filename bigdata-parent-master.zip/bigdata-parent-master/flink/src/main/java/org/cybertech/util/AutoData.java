package org.cybertech.util;

import com.util.common.redis.RedisHashUtil;
import org.cybertech.datasourceDelivery.generator.ChineseAddressGenerator;
import org.cybertech.datasourceDelivery.generator.ChineseMobileNumberGenerator;
import org.cybertech.datasourceDelivery.generator.ChineseNameGenerator;
import org.cybertech.datasourceDelivery.util.RandType;
import org.cybertech.entity.Delivery;
import org.cybertech.entity.ProvinceCity;

import java.util.*;

public class AutoData {
    public static Delivery generateData() {
        List<ProvinceCity> provinceCityList = new ArrayList<>();
        RedisHashUtil redisHashUtil = new RedisHashUtil();
        Map<Object, Object> province_percent = redisHashUtil.hGetAll("province_percent");
        Iterator<Map.Entry<Object, Object>> iterator = province_percent.entrySet().iterator();
        while (iterator.hasNext()){
            Map.Entry<Object, Object> next = iterator.next();
            String key = String.valueOf(next.getKey());
            int value = Integer.parseInt(String.valueOf(next.getValue()));
            Map<Object, Object> city_percent = redisHashUtil.hGetAll(key);
            Iterator<Map.Entry<Object, Object>> iteratorCity = city_percent.entrySet().iterator();
            while (iteratorCity.hasNext()){
                Map.Entry<Object, Object> city = iteratorCity.next();
                String cityKey = String.valueOf(city.getKey());
                int cityValue = Integer.parseInt(String.valueOf(city.getValue()));
                ProvinceCity provinceCity = null;
                for(int i=0;i<value * cityValue;i++){
                    provinceCity = new ProvinceCity();
                    provinceCity.setProvinceName(key);
                    provinceCity.setCityName(cityKey);
                    provinceCityList.add(provinceCity);
                }
            }
        }

        Delivery delivery = new Delivery();
        //寄件人姓名
        ChineseNameGenerator instance = ChineseNameGenerator.getInstance();
        String xm = instance.generate();
        delivery.setXm(xm);

        //寄件人手机号码
        ChineseMobileNumberGenerator chineseMobileNumberGenerator = new ChineseMobileNumberGenerator();
        String sjhm = chineseMobileNumberGenerator.generate();
        delivery.setSjhm(sjhm);

        ProvinceCity provinceCity = null;
        //省、市
        int randomNum = new Random().nextInt(provinceCityList.size()-1);
        System.out.println(">>>>>randomNum:"+randomNum);
        provinceCity = provinceCityList.get(randomNum);
        String provinceName = provinceCity.getProvinceName();
        String cityName = provinceCity.getCityName();
        delivery.setProvince(provinceName);
        delivery.setCity(cityName);
        //地址
        String address = provinceName+cityName+ ChineseAddressGenerator.getInstance().generate();
        delivery.setAddress(address);

        //时间
        String sendTime = RandType.currentTime();
        delivery.setSendTime(sendTime);

        return delivery;
    }
}
