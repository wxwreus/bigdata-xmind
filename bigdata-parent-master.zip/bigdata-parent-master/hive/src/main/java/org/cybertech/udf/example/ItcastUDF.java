package org.cybertech.udf.example;

import org.apache.hadoop.io.Text;

public class ItcastUDF {

    public Text evaluate(final Text s) {
        if (null == s) {
            return null;
        }
        //返回大写字母
        return new Text(s.toString().toUpperCase());

    }
}
