package com.htsc.case_user_order;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class LeftJoinWritable implements Writable {

    private String tag;
    private String data;

    public LeftJoinWritable() {}

    public LeftJoinWritable(String tag, String data) {
        this.set(tag, data);
    }

    public void set(String tag, String data) {
        this.tag = tag;
        this.data = data;
    }
    public void set(String data) {
        this.data = data;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(this.getTag());
        dataOutput.writeUTF(this.getData());
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.setTag(dataInput.readUTF());
        this.setData(dataInput.readUTF());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LeftJoinWritable that = (LeftJoinWritable) o;
        return Objects.equals(tag, that.tag) && Objects.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tag, data);
    }

    @Override
    public String toString() {
        return "LeftJoinWritable{" +
                "tag='" + tag + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}
