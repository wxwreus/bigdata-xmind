package com.htsc.case_user_order;

import com.htsc.util.DataCommon;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class LeftOutJoinMapper extends Mapper<LongWritable, Text, Text, LeftJoinWritable> {

    Text outputKey = new Text();
    LeftJoinWritable outputValue = new LeftJoinWritable();

    @Override
    protected void setup(Mapper<LongWritable, Text, Text, LeftJoinWritable>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, LeftJoinWritable>.Context context) throws IOException, InterruptedException {
        String[] split = value.toString().split(",");
        System.out.println(">>>>>out>>>>"+value.toString());
        if(split.length !=3 && split.length !=5){
            return;
        }
        if(split.length==3){//用户数据
            String uid = split[0];
            String uname = split[1];
            String uposition = split[2];
            outputKey.set(uid);
//            outputValue.set(DataCommon.CUSTOMER,uname+","+uposition);
            outputValue.set(DataCommon.CUSTOMER, uposition);

        }
        if(split.length==5){//订单数据
            //tid,store,uid,nums,price
            String tid = split[0];
            String store = split[1];
            String uid = split[2];
            String nums = split[3];
            String price = split[4];
            outputKey.set(uid);
            outputValue.set(DataCommon.ORDER,tid+","+store+","+nums+","+price);
        }
        context.write(outputKey,outputValue);
    }

    @Override
    protected void cleanup(Mapper<LongWritable, Text, Text, LeftJoinWritable>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
