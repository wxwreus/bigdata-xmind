package com.htsc.case_user_order;

import com.htsc.util.DataCommon;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LeftOutJoinReducer extends Reducer<Text, LeftJoinWritable, NullWritable, Text > {

    Text outputKey = new Text();
    Text outputValue = new Text();
    @Override
    protected void setup(Reducer<Text, LeftJoinWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void reduce(Text key, Iterable<LeftJoinWritable> values, Reducer<Text, LeftJoinWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {

        String positionInfo = "";
        List<String> orderList = new ArrayList<>();

        Iterator<LeftJoinWritable> iterator = values.iterator();
        while(iterator.hasNext()){
            LeftJoinWritable next = iterator.next();
            if(DataCommon.CUSTOMER.equals(next.getTag())){
                positionInfo =  next.getData();

            }else if(DataCommon.ORDER.equals(next.getTag())){
                orderList.add(next.getData());
            }
        }
        if(orderList.size()>0){
            for (String order : orderList){
                String store = order.split(",")[1];
//                outputValue.set(userInfo +","+ order);
                outputKey.set(store+" \t");
                outputValue.set(store+","+positionInfo);
                context.write(NullWritable.get(),outputValue);
            }
        }


    }

    @Override
    protected void cleanup(Reducer<Text, LeftJoinWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
