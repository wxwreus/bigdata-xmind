package com.htsc.case_user_order;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;

public class PositionCountDriver extends Configured implements Tool {

    @Override
    public int run(String[] args) throws IOException,ClassNotFoundException,InterruptedException {

        Configuration configuration = this.getConf();
        configuration.addResource(new Path("D:\\program\\code\\bigdata\\MapperReduce\\src\\main\\resources\\core-site.xml"));
        Job firstJob = null;
        boolean isSuccess = false;
        FileSystem fileSystem = FileSystem.get(configuration);
        //
        firstJob = Job.getInstance(configuration,"leftOutJoin");//this.getClass().getSimpleName()
        firstJob.setJarByClass(this.getClass());
        //input
        Path path = new Path(args[0]);
        FileInputFormat.addInputPath(firstJob,path);
        //map设置输入输出类型
        firstJob.setMapperClass(LeftOutJoinMapper.class);
        firstJob.setMapOutputKeyClass(Text.class);
        firstJob.setMapOutputValueClass(LeftJoinWritable.class);
        //分区
        //排序
        //分组
        //combiner
//			job.setCombinerClass(WordCountCombiner.class);
        //compress
//			configuration.set("mapreduce.map.output.compress","true");
//			configuration.set("mapreduce.map.output.compress.codec","org.apache.hadoop.io.compress.SnappyCodec");//算法
//			job.setNumReduceTasks(2);
        //reduce设置输入输出类型（join）
        firstJob.setReducerClass(LeftOutJoinReducer.class);
        firstJob.setOutputKeyClass(Text.class);
        firstJob.setOutputValueClass(Text.class);
//        firstJob.setOutputFormatClass(SequenceFileOutputFormat.class);
        //out
        Path outPath = new Path(args[1]);
        if(fileSystem.exists(outPath)){
            fileSystem.delete(outPath,true);
        }
        FileOutputFormat.setOutputPath(firstJob,outPath);
        isSuccess = firstJob.waitForCompletion(true);
        if(isSuccess){
            Job secondJob = Job.getInstance(configuration,"nt");//this.getClass().getSimpleName()
            secondJob.setJarByClass(this.getClass());
            //input
            Path countInputPath = new Path(args[1]);
            FileInputFormat.addInputPath(secondJob,countInputPath);
            //map设置输入输出类型
            secondJob.setMapperClass(PositionCountMapper.class);
            secondJob.setMapOutputKeyClass(Text.class);
            secondJob.setMapOutputValueClass(Text.class);
            //reduce设置输入输出类型(count)
            secondJob.setReducerClass(PositionCountReducer.class);
            secondJob.setOutputKeyClass(Text.class);
            secondJob.setOutputValueClass(Text.class);
//            secondJob.setOutputFormatClass(SequenceFileOutputFormat.class);
            //out
            Path countOutPath = new Path(args[2]);
            if(fileSystem.exists(countOutPath)){
                fileSystem.delete(countOutPath,true);
            }
            FileOutputFormat.setOutputPath(secondJob,countOutPath);
            try {
                boolean r = secondJob.waitForCompletion(true);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
            }

        }
        return isSuccess?1:0;
    }

    public static void main(String[] args) {

        args = new String[]{
                "hdfs://bigdata-pro01:9000/ods/user_order",
                "hdfs://bigdata-pro01:9000/ods/output",
                "hdfs://bigdata-pro01:9000/ods/countoutput"
        };
        Configuration configuration = new Configuration();
        try {
            int status = ToolRunner.run(configuration,new PositionCountDriver(),args);
            System.exit(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
