package com.htsc.case_user_order;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class PositionCountMapper extends Mapper<LongWritable, Text, Text, Text> {

    Text outputKey = new Text();
    Text outputValue = new Text();
    @Override
    protected void setup(Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        outputKey.set(value.toString().split(",")[0]);
        outputValue.set(value.toString().split(",")[1]);
        context.write(outputKey,outputValue);
    }

    @Override
    protected void cleanup(Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
