package com.htsc.case_user_order;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.HashSet;

public class PositionCountReducer extends Reducer<Text, Text, Text, Text> {

    @Override
    protected void setup(Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {

        HashSet<String> positions = new HashSet<>();
        for(Text value : values){
            //uposition
            positions.add(value.toString());
        }
        System.out.println("key="+key.toString()+",value="+positions.toString());
        context.write(key,new Text(positions.toString()));
    }

    @Override
    protected void cleanup(Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
