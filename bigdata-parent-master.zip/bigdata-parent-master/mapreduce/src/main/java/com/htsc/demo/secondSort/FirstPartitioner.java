package com.htsc.demo.secondSort;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Partitioner;

public class FirstPartitioner extends Partitioner<PairWritable, IntWritable> {

	@Override
	public int getPartition(PairWritable key, IntWritable intWritable, int i) {
		return (key.hashCode() & 2147483647) % i;
	}
}
