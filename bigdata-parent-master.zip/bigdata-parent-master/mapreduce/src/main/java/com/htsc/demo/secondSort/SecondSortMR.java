package com.htsc.demo.secondSort;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;

public class SecondSortMR extends Configured implements Tool {

	//map
	public static class TemplateMapper extends Mapper<LongWritable, Text, PairWritable, IntWritable>{

		private PairWritable outputKey = new PairWritable();
		private IntWritable outputValue = new IntWritable();

		@Override
		protected void setup(Context context) throws IOException, InterruptedException {

		}

		@Override
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			String[] values = value.toString().split(" ");
			if(values.length != 2){
				return;
			}
			outputKey.set(values[0],Integer.parseInt(values[1]));
			outputValue.set(Integer.parseInt(values[1]));
			System.out.println(">>>>>key:"+values[0]+",>>>>>value:"+values[1]);
			context.write(outputKey,outputValue);
		}

		@Override
		protected void cleanup(Context context) throws IOException, InterruptedException {

		}
	}
	//reduce
	public static class TemplateReduce extends Reducer<PairWritable, IntWritable, Text, IntWritable>{

		private IntWritable outputValue = new IntWritable();
		private Text text = new Text();

		@Override
		protected void setup(Context context) throws IOException, InterruptedException {

		}

		@Override
		protected void reduce(PairWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

			System.out.println(">>>>>>>>>>>>>>>>>>key:"+key+",values:"+values);
			for (IntWritable value : values){
				text.set(key.getFirst());
				context.write(text,value);
			}

		}

		@Override
		protected void cleanup(Context context) throws IOException, InterruptedException {

		}
	}

	//driver
	@Override
	public int run(String[] args){
		Configuration configuration = this.getConf();
		configuration.addResource(new Path("D:/program/code/hadoop/src/main/resources/core-site.xml"));
		Job job = null;
		boolean isSuccess = false;
		try {
			FileSystem fileSystem = FileSystem.get(configuration);

			job = Job.getInstance(configuration,this.getClass().getSimpleName());
			job.setJarByClass(this.getClass());
			//input
			Path path = new Path(args[0]);
			FileInputFormat.addInputPath(job,path);
			//map
			job.setMapperClass(TemplateMapper.class);
			job.setMapOutputKeyClass(PairWritable.class);
			job.setMapOutputValueClass(IntWritable.class);
			//分区
			job.setPartitionerClass(FirstPartitioner.class);
			//排序

			//分组
			job.setGroupingComparatorClass(FirstGrouping.class);
			//combiner
//			job.setCombinerClass(WordCountCombiner.class);

			//compress
			configuration.set("mapreduce.map.output.compress","true");
			configuration.set("mapreduce.map.output.compress.codec","org.apache.hadoop.io.compress.SnappyCodec");//算法

//			job.setNumReduceTasks(2);
			//reduce
			job.setReducerClass(TemplateReduce.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(IntWritable.class);
			//out
			Path outPath = new Path(args[1]);
			if(fileSystem.exists(outPath)){
				fileSystem.delete(outPath,true);
			}
			FileOutputFormat.setOutputPath(job,outPath);
			//commit
			try {
				isSuccess = job.waitForCompletion(true);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return isSuccess?1:0;
	}

	public static void main(String[] args) {

		args = new String[]{
				"hdfs://bigdata-pro01.kfk.com:9000/user/datas/secondSort",
				"hdfs://bigdata-pro01.kfk.com:9000/user/datas/output/"
		};
		Configuration configuration = new Configuration();
		try {
			int status = ToolRunner.run(configuration,new SecondSortMR(),args);
			System.exit(status);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
