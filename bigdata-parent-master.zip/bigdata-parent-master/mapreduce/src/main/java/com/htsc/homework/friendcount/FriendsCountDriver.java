package com.htsc.homework.friendcount;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class FriendsCountDriver extends Configured implements Tool {

    @Override
    public int run(String[] args) throws Exception {
        Configuration configuration = this.getConf();
        configuration.addResource(new Path("D:\\program\\code\\bigdata\\MapperReduce\\src\\main\\resources\\core-site.xml"));
        Job job = null;
        boolean isSuccess = false;
        FileSystem fileSystem = FileSystem.get(configuration);
        //
        job = Job.getInstance(configuration,this.getClass().getSimpleName());
        job.setJarByClass(this.getClass());
        //添加input
        Path path = new Path(args[0]);
        FileInputFormat.addInputPath(job,path);

        //map设置输入输出类型
        job.setMapperClass(FCMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);

        //reduce设置输入输出类型
        job.setReducerClass(FCReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);
//        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        //添加输出结果路径
        Path outPath = new Path(args[1]);
        if(fileSystem.exists(outPath)){
            fileSystem.delete(outPath,true);
        }
        FileOutputFormat.setOutputPath(job,outPath);
        isSuccess = job.waitForCompletion(true);
        return isSuccess?1:0;
    }

    /**
     * 执行程序入口
     * @param args
     */
    public static void main(String[] args) {
        //文件路径
        args = new String[]{"file:///C:/Users/Administrator/Desktop/input_friendcount_friends",
                "hdfs://bigdata-pro01:9000/ods/output",};
        Configuration configuration = new Configuration();
        try {
            int status = ToolRunner.run(configuration,new FriendsCountDriver(),args);
            System.exit(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
