package com.htsc.homework.kmer_order;

import com.htsc.homework.kmercount.KCMapper;
import com.htsc.homework.kmercount.KCReducer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.net.URI;

public class KCOrderDriver extends Configured implements Tool {

    @Override
    public int run(String[] args) throws Exception {
        Configuration configuration = this.getConf();
        configuration.addResource(new Path("D:\\program\\code\\bigdata\\MapperReduce\\src\\main\\resources\\core-site.xml"));
        Job job = null;
        boolean isSuccess = false;
        FileSystem fileSystem = FileSystem.get(configuration);
        //
        job = Job.getInstance(configuration,this.getClass().getSimpleName());
        job.setJarByClass(this.getClass());
        //添加input
        Path path = new Path(args[0]);
        FileInputFormat.addInputPath(job,path);

        //map设置输入输出类型
        job.setMapperClass(KCOrderMapper.class);
        job.setMapOutputKeyClass(LongWritable.class);
        job.setMapOutputValueClass(Text.class);
        job.setNumReduceTasks(1);
        //reduce设置输入输出类型
        job.setReducerClass(KCOrderReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
//        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        //添加输出结果路径
        URI uri = new URI(args[1]);
        job.addCacheFile(uri);
        Path outPath = new Path(args[2]);
        if(fileSystem.exists(outPath)){
            fileSystem.delete(outPath,true);
        }
        FileOutputFormat.setOutputPath(job,outPath);
        isSuccess = job.waitForCompletion(true);
        return isSuccess?1:0;
    }

    /**
     * 主程序入口
     * @param args
     */
    public static void main(String[] args) {
        //文件路径
        args = new String[]{"file:///C:/Users/Administrator/Desktop/input_KmerCounter_genomes",//元数据文件
                "hdfs://bigdata-pro01:9000/ods/output",         //中间结果，缓存
                "hdfs://bigdata-pro01:9000/ods/output1"};       //最终结果
        Configuration configuration = new Configuration();
        try {
            int status = ToolRunner.run(configuration,new KCOrderDriver(),args);
            System.exit(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
