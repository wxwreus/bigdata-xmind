package com.htsc.homework.kmer_order;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class KCOrderMapper  extends Mapper<LongWritable, Text, LongWritable, Text> {

    Text outputKey = new Text();

    @Override
    protected void setup(Mapper<LongWritable, Text, LongWritable, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, LongWritable, Text>.Context context) throws IOException, InterruptedException {
        String values = value.toString();
        //过滤脏数据
        if(values.length()<3){
            return;
        }

        //输出长度为3的kmer    key:location
        for(int i=0;i<values.length();i++){
            if(i<=values.length()-3){
                String kmer = String.valueOf(values.charAt(i))+String.valueOf(values.charAt(i+1))+String.valueOf(values.charAt(i+2));
                outputKey.set(kmer);
                context.write(new LongWritable(i+1),outputKey);
            }
        }
    }

    @Override
    protected void cleanup(Mapper<LongWritable, Text, LongWritable, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
