package com.htsc.homework.kmer_order;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class KCOrderReducer extends Reducer<LongWritable, Text, Text, Text> {

    static Map<String,Long> customerMaps = new HashMap<>();//缓存数据
    @Override
    protected void setup(Reducer<LongWritable, Text, Text, Text>.Context context) throws IOException {
//        System.out.println(">>>>>>cache start>>>>>>>");
//        Configuration configuration = context.getConfiguration();
//        try {
//            URI[] uris = Job.getInstance(configuration).getCacheFiles();
//            Path path = new Path("hdfs://bigdata-pro01:9000/ods/output/part-r-00000");
//            FileSystem fileSystem = FileSystem.get(configuration);
//            InputStream inputStream = fileSystem.open(path);
//
//            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
//            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
//            String line = null;
//            while((line = bufferedReader.readLine()) != null){
//                if(line.trim().length() > 0){
//                    customerMaps.put(line.split(",")[0],Long.parseLong(line.split(",")[1]));
//                }
//            }
//            bufferedReader.close();
//            inputStreamReader.close();
//            inputStream.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        System.out.println(">>>>>>cache end>>>>>>>");

        Configuration conf=new Configuration();
        FileSystem hdfs=FileSystem.get(conf);
        //这里的路径是在hdfs上的存放路径，但是事先需将hdfs-site.xml文件放在工程的source文件下，这样才能找到hdfs
        Path path=new Path("hdfs://bigdata-pro01:9000/ods/output/");
        FileStatus[] stats=hdfs.listStatus(path);
        for (int i=0; i<stats.length; i++){
            //打印每个文件路径
            System.out.println(stats[i].getPath().toString());
            //读取每个文件
            InputStream inputStream=hdfs.open(stats[i].getPath());
            InputStreamReader inputStreamReader= new InputStreamReader(inputStream);
            BufferedReader reader=new BufferedReader(inputStreamReader);
            String line="";
            while((line=reader.readLine())!=null){
                System.out.println(line);
                //可以在这里对每一条数据进行处理
                if(line.trim().length() > 0){
                    customerMaps.put(line.split(",")[0],Long.parseLong(line.split(",")[1]));
                }
            }
            reader.close();
            inputStreamReader.close();
            inputStream.close();
        }
    }

    @Override
    protected void reduce(LongWritable key, Iterable<Text> values, Reducer<LongWritable, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {

        Iterator<Text> iterator = values.iterator();
        while (iterator.hasNext()){
            Text outputKey = iterator.next();
            Long aCnt = customerMaps.get(outputKey.toString());
            System.out.println(outputKey.toString()+"  "+key.get()+"  "+aCnt);
            context.write(outputKey,new Text(key+","+aCnt));
        }
    }

    @Override
    protected void cleanup(Reducer<LongWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
