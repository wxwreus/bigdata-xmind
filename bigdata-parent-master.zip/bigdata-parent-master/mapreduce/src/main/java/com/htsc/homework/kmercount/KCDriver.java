package com.htsc.homework.kmercount;

import com.htsc.homework.friendcount.FCMapper;
import com.htsc.homework.friendcount.FCReducer;
import com.htsc.homework.friendcount.FriendsCountDriver;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class KCDriver  extends Configured implements Tool {

    @Override
    public int run(String[] args) throws Exception {
        Configuration configuration = this.getConf();
        configuration.addResource(new Path("D:\\program\\code\\bigdata\\MapperReduce\\src\\main\\resources\\core-site.xml"));
        Job job = null;
        boolean isSuccess = false;
        FileSystem fileSystem = FileSystem.get(configuration);
        //
        job = Job.getInstance(configuration,this.getClass().getSimpleName());
        job.setJarByClass(this.getClass());
        //添加input
        Path path = new Path(args[0]);
        FileInputFormat.addInputPath(job,path);

        //map设置输入输出类型
        job.setMapperClass(KCMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);

        //reduce设置输入输出类型
        job.setReducerClass(KCReducer.class);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);
//        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        //添加输出结果路径
        Path outPath = new Path(args[1]);
        if(fileSystem.exists(outPath)){
            fileSystem.delete(outPath,true);
        }
        FileOutputFormat.setOutputPath(job,outPath);
        isSuccess = job.waitForCompletion(true);
        return isSuccess?1:0;
    }

    public static void main(String[] args) {
        //文件路径
        args = new String[]{"file:///C:/Users/Administrator/Desktop/input_KmerCounter_genomes",
                "hdfs://bigdata-pro01:9000/ods/output",};
        Configuration configuration = new Configuration();
        try {
            int status = ToolRunner.run(configuration,new KCDriver(),args);
            System.exit(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
