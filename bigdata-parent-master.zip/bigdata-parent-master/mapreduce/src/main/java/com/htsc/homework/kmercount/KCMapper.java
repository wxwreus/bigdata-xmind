package com.htsc.homework.kmercount;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class KCMapper extends Mapper<LongWritable, Text, Text, LongWritable> {

    Text outputKey = new Text();
    LongWritable outputValue = new LongWritable(1);

    @Override
    protected void setup(Mapper<LongWritable, Text, Text, LongWritable>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, LongWritable>.Context context) throws IOException, InterruptedException {
        String values = value.toString();
        //过滤脏数据
        if(values.length()<3){
            return;
        }
        //输出长度为3的kmer
        for(int i=0;i<values.length();i++){
            if(i<=values.length()-3){
                String kmer = String.valueOf(values.charAt(i))+String.valueOf(values.charAt(i+1))+String.valueOf(values.charAt(i+2));
                outputKey.set(kmer);
                context.write(outputKey,outputValue);
            }
        }
    }

    @Override
    protected void cleanup(Mapper<LongWritable, Text, Text, LongWritable>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
