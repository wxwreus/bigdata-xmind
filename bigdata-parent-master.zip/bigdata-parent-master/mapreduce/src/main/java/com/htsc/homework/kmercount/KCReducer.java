package com.htsc.homework.kmercount;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.Iterator;

public class KCReducer extends Reducer<Text, LongWritable, NullWritable, Text> {

    @Override
    protected void setup(Reducer<Text, LongWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void reduce(Text key, Iterable<LongWritable> values, Reducer<Text, LongWritable, NullWritable, Text>.Context context)
            throws IOException, InterruptedException {
        Iterator<LongWritable> iterator = values.iterator();
        Long cnt = 0L;
        while (iterator.hasNext()){
            cnt += iterator.next().get();
        }
        System.out.println(key +"   "+ cnt);
        context.write(NullWritable.get(),new Text(key+","+cnt));
    }

    @Override
    protected void cleanup(Reducer<Text, LongWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
