package com.htsc.homework.student_score;

import com.htsc.homework.friendcount.FCMapper;
import com.htsc.homework.friendcount.FCReducer;
import com.htsc.util.DataJoinWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * 学生 -- 分数
 * 学生：学生id,姓名,出生年份
 * 分数：学生id,课程1,课程2,课程3
 */
public class SCJoinDriver  extends Configured implements Tool {

    @Override
    public int run(String[] args) throws Exception {
        Configuration configuration = this.getConf();
        configuration.addResource(new Path("D:\\program\\code\\bigdata\\MapperReduce\\src\\main\\resources\\core-site.xml"));
        Job job = null;
        boolean isSuccess = false;
        FileSystem fileSystem = FileSystem.get(configuration);
        //
        job = Job.getInstance(configuration,this.getClass().getSimpleName());
        job.setJarByClass(this.getClass());
        //添加input
        Path inptpath1 = new Path(args[0]);
        FileInputFormat.addInputPath(job,inptpath1);
        Path inptpath2 = new Path(args[1]);
        FileInputFormat.addInputPath(job,inptpath2);

        //map设置输入输出类型
        job.setMapperClass(SCMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DataJoinWritable.class);

        //reduce设置输入输出类型
        job.setReducerClass(SCReducer.class);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);
//        job.setOutputFormatClass(SequenceFileOutputFormat.class);

        //添加输出结果路径
        Path outPath = new Path(args[2]);
        if(fileSystem.exists(outPath)){
            fileSystem.delete(outPath,true);
        }
        FileOutputFormat.setOutputPath(job,outPath);
        isSuccess = job.waitForCompletion(true);
        return isSuccess?1:0;
    }

    /**
     * 执行程序入口
     * @param args
     */
    public static void main(String[] args) {

        //输入输出文件路径
        args = new String[]{"file:///C:/Users/Administrator/Desktop/input_student.csv",
                "file:///C:/Users/Administrator/Desktop/input_score.csv",
                "hdfs://bigdata-pro01:9000/ods/output"};
        Configuration configuration = new Configuration();
        try {
            int status = ToolRunner.run(configuration,new SCJoinDriver(),args);
            System.exit(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
