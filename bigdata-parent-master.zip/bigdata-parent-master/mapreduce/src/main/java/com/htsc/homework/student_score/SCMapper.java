package com.htsc.homework.student_score;

import com.htsc.case_user_order.LeftJoinWritable;
import com.htsc.util.DataCommon;
import com.htsc.util.DataJoinWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * map阶段
 * 读取文件信息-对数据进行简单转换处理
 * 要求：
 * a.出生年份大于1990
 * b.课程1的成绩大于80分，且课程2的成绩小于95分
 */
public class SCMapper extends Mapper<LongWritable, Text, Text, DataJoinWritable> {

    Text outputKey = new Text();
    DataJoinWritable outputValue = new DataJoinWritable();

    @Override
    protected void setup(Mapper<LongWritable, Text, Text, DataJoinWritable>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, DataJoinWritable>.Context context) throws IOException, InterruptedException {

        System.out.println(">>>>>ll>>>>"+value.toString());
        String[] split = value.toString().split(",");
        //过滤不合格的数据
        if(split.length !=3 && split.length !=4){
            return;
        }
        if(split.length==3){//学生表数据
            String sid = split[0];
            String name = split[1];
            int birth = Integer.parseInt(split[2]);
            outputKey.set(sid);
            //出生年份大于1990
            if(birth>1990){
                System.out.println(">>>>>birth>>>>"+birth);
                outputValue.set(DataCommon.STU, sid+","+name+","+birth);
            }
//            outputValue.set(DataCommon.STU, sid+","+name+","+birth);
        }
        if(split.length==4){//成绩表数据
            String sid = split[0];
            int course1 = Integer.parseInt(split[1]);
            int course2 = Integer.parseInt(split[2]);
            int course3 = Integer.parseInt(split[3]);
            outputKey.set(sid);
            if(course1>80 && course2<95){
                outputValue.set(DataCommon.SCORE,course1+","+course2+","+course3);
            }
//            outputValue.set(DataCommon.SCORE,course1+","+course2+","+course3);
        }
        context.write(outputKey,outputValue);
    }

    @Override
    protected void cleanup(Mapper<LongWritable, Text, Text, DataJoinWritable>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
