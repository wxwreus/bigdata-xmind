package com.htsc.homework.student_score;

import com.htsc.util.DataCommon;
import com.htsc.util.DataJoinWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.Iterator;

public class SCReducer  extends Reducer<Text, DataJoinWritable, NullWritable, Text > {

    @Override
    protected void setup(Reducer<Text, DataJoinWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void reduce(Text key, Iterable<DataJoinWritable> values, Reducer<Text, DataJoinWritable, NullWritable, Text>.Context context)
            throws IOException, InterruptedException {

        Iterator<DataJoinWritable> iterator = values.iterator();
        String stuText = "";
        String courseText = "";
        while(iterator.hasNext()){
            DataJoinWritable next = iterator.next();
            if(DataCommon.STU.equals(next.getTag())){
                stuText = next.getData();
            }else if(DataCommon.SCORE.equals(next.getTag())){
                courseText = next.getData();
            }
        }
        if(stuText != null && courseText != null){
            String fullText = stuText + "," + courseText;
            System.out.println("fullText>>>>>"+fullText);
            context.write(NullWritable.get(),new Text(fullText));
        }
    }

    @Override
    protected void cleanup(Reducer<Text, DataJoinWritable, NullWritable, Text>.Context context) throws IOException, InterruptedException {
        super.cleanup(context);
    }
}
