package com.htsc.join;

import com.htsc.util.DataCommon;
import com.htsc.util.DataJoinWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataJoinMR  extends Configured implements Tool {

    //map
    public static class TemplateMapper extends Mapper<LongWritable, Text, Text, DataJoinWritable> {

        Text outputKey = new Text();
        DataJoinWritable outputValue = new DataJoinWritable();

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            String[] values = value.toString().split(",");
            if(values.length !=3 && values.length !=4){
                return;
            }
            //customer
            if(values.length == 3){
                String cid = values[0];
                String name = values[1];
                String tel = values[2];
                outputKey.set(cid);
                outputValue.set(DataCommon.CUSTOMER, name +","+ tel);
                context.write(outputKey,outputValue);
            }
            //order
            if(values.length == 5){
                String cid = values[1];
                String price = values[2];
                String productName = values[3];
                outputKey.set(cid);
                outputValue.set(DataCommon.ORDER, price +","+ productName);
                context.write(outputKey,outputValue);
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {

        }
    }
    //reduce
    public static class TemplateReduce extends Reducer<Text, DataJoinWritable, NullWritable, Text> {

        Text outputValue = new Text();

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void reduce(Text key, Iterable<DataJoinWritable> values, Context context) throws IOException, InterruptedException {

            String customerInfo = "";
            List<String> orderList = new ArrayList<>();
            System.out.println("--------------------start--------------------:");

            for(DataJoinWritable dataJoinWritable : values){
                System.out.println(dataJoinWritable.toString());
                if(DataCommon.CUSTOMER.equals(dataJoinWritable.getTag())){
                    customerInfo = dataJoinWritable.getData();
                }else if(DataCommon.ORDER.equals(dataJoinWritable.getTag())){
                    orderList.add(dataJoinWritable.getData());
                }
            }
            for(String orderInfo : orderList){
                outputValue.set(key +","+ customerInfo +","+ orderInfo);
                context.write(NullWritable.get(),outputValue);
            }
            System.out.println("--------------------end--------------------:");
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {

        }
    }

    //driver
    @Override
    public int run(String[] args){
        Configuration configuration = this.getConf();
        configuration.addResource(new Path("D:\\program\\code\\bigdata\\MapperReduce\\src\\main\\resources\\core-site.xml"));
        Job job = null;
        boolean isSuccess = false;
        try {
            FileSystem fileSystem = FileSystem.get(configuration);
            job = Job.getInstance(configuration,this.getClass().getSimpleName());
            job.setJarByClass(this.getClass());
            //input
            Path path = new Path(args[0]);
            FileInputFormat.addInputPath(job,path);
            //map设置输入输出类型
            job.setMapperClass(TemplateMapper.class);
            job.setMapOutputKeyClass(Text.class);
            job.setMapOutputValueClass(DataJoinWritable.class);
            //分区

            //排序

            //分组

            //combiner
//			job.setCombinerClass(WordCountCombiner.class);

            //compress
//			configuration.set("mapreduce.map.output.compress","true");
//			configuration.set("mapreduce.map.output.compress.codec","org.apache.hadoop.io.compress.SnappyCodec");//算法
//
//			job.setNumReduceTasks(2);
            //reduce设置输入输出类型
            job.setReducerClass(TemplateReduce.class);
            job.setOutputKeyClass(NullWritable.class);
            job.setOutputValueClass(Text.class);
            //out
            Path outPath = new Path(args[1]);
            if(fileSystem.exists(outPath)){
                fileSystem.delete(outPath,true);
            }
            FileOutputFormat.setOutputPath(job,outPath);
            //commit
            try {
                isSuccess = job.waitForCompletion(true);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return isSuccess?1:0;
    }

    public static void main(String[] args) {

        args = new String[]{
                "hdfs://bigdata-pro01:9000/ods/user_order/",
                "hdfs://bigdata-pro01:9000/ods/user_order/output"
        };
        Configuration configuration = new Configuration();
        try {
            int status = ToolRunner.run(configuration,new DataJoinMR(),args);
            System.exit(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
