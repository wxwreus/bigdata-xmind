package com.htsc.join;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class DistributedCacheMR extends Configured implements Tool {

	static Map<String,String> customerMaps = new HashMap<>();
	//map
	public static class TemplateMapper extends Mapper<LongWritable, Text, Text, Text>{

		Text outputKey = new Text();
		Text outputValue = new Text();

		@Override
		protected void setup(Context context) throws IOException, InterruptedException {
			Configuration configuration = context.getConfiguration();
			URI[] uris = Job.getInstance(configuration).getCacheFiles();
			Path path = new Path(uris[0]);
			FileSystem fileSystem = FileSystem.get(configuration);
			InputStream inputStream = fileSystem.open(path);

			InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
			String line = null;
			while((line = bufferedReader.readLine()) != null){
				if(line.trim().length() > 0){
					customerMaps.put(line.split(",")[0],line);
				}
			}
			bufferedReader.close();
			inputStreamReader.close();
			inputStream.close();
		}

		@Override
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			//100,1,45.50,product-1
			String lineValue = value.toString();
			StringTokenizer stringTokenizer = new StringTokenizer(lineValue,",");
			while(stringTokenizer.hasMoreTokens()){
				String wordValue = stringTokenizer.nextToken();
				if(customerMaps.get(wordValue) != null){
					outputKey.set(wordValue);
					outputValue.set(customerMaps.get(wordValue)+lineValue);
					context.write(outputKey,outputValue);
					break;
				}
			}
		}
		@Override
		protected void cleanup(Context context) throws IOException, InterruptedException {

		}
	}
	//reduce
	public static class TemplateReduce extends Reducer<Text, IntWritable, Text, IntWritable>{



		@Override
		protected void setup(Context context) throws IOException, InterruptedException {

		}

		@Override
		protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

		}

		@Override
		protected void cleanup(Context context) throws IOException, InterruptedException {

		}
	}

	//driver
	@Override
	public int run(String[] args)throws Exception{
		Configuration configuration = this.getConf();
		configuration.addResource(new Path("D:/program/code/hadoop/src/main/resources/core-site.xml"));
		Job job = null;
		boolean isSuccess = false;
		try {
			FileSystem fileSystem = FileSystem.get(configuration);

			job = Job.getInstance(configuration,this.getClass().getSimpleName());
			job.setJarByClass(this.getClass());
			//input
			Path path = new Path(args[0]);
			FileInputFormat.addInputPath(job,path);
			//map
			job.setMapperClass(TemplateMapper.class);
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(Text.class);
			//分区

			//排序

			//分组

			//combiner
//			job.setCombinerClass(WordCountCombiner.class);

			//compress
//			configuration.set("mapreduce.map.output.compress","true");
//			configuration.set("mapreduce.map.output.compress.codec","org.apache.hadoop.io.compress.SnappyCodec");//算法

//			job.setNumReduceTasks(2);
			//reduce
//			job.setReducerClass(TemplateReduce.class);
//			job.setOutputKeyClass(Text.class);
//			job.setOutputValueClass(IntWritable.class);
			URI uri = new URI(args[2]);
			job.addCacheFile(uri);
			//out
			Path outPath = new Path(args[1]);
			if(fileSystem.exists(outPath)){
				fileSystem.delete(outPath,true);
			}
			FileOutputFormat.setOutputPath(job,outPath);
			//commit
			try {
				isSuccess = job.waitForCompletion(true);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return isSuccess?1:0;
	}

	public static void main(String[] args) {

		args = new String[]{
				"hdfs://bigdata-pro02.kfk.com:9000/user/datas/order.txt",
				"hdfs://bigdata-pro02.kfk.com:9000/user/datas/output/",
				"hdfs://bigdata-pro02.kfk.com:9000/user/datas/customer.txt"
		};
		Configuration configuration = new Configuration();
		try {
			int status = ToolRunner.run(configuration,new DistributedCacheMR(),args);
			System.exit(status);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
