package com.htsc.util;

public class DataCommon {
	public final static String CUSTOMER = "customer";	//消费者
	public final static String ORDER = "order";			//订单

	public final static String STU = "student";			//学生
	public final static String SCORE = "score";			//分数


}
